To run this program, use command following:
java -jar wheelOfFortune.jar